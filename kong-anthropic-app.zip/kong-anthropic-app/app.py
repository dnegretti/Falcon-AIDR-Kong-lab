#!/usr/bin/env python3
"""
app.py - Consulta a Anthropic a traves de Kong AI Gateway.

Kong expone un endpoint compatible con OpenAI en /chat, traduce el request
al formato de Anthropic, agrega la API key, y devuelve la respuesta.
La app NO conoce la API key de Anthropic: solo habla con Kong.
"""

import sys
import requests

# URL del endpoint de Kong (la ruta /chat definida en kong.yaml).
KONG_URL = "http://localhost:8000/chat"

# Timeout generoso para respuestas largas del modelo.
TIMEOUT_SECONDS = 120


def preguntar(mensaje, historial=None):
    """
    Envia un mensaje a Anthropic via Kong y devuelve el texto de la respuesta.

    mensaje:   str con la pregunta del usuario.
    historial: lista opcional de mensajes previos en formato
               [{"role": "user"/"assistant", "content": "..."}].
    """
    mensajes = list(historial) if historial else []
    mensajes.append({"role": "user", "content": mensaje})

    payload = {
        "messages": mensajes,
    }

    try:
        resp = requests.post(KONG_URL, json=payload, timeout=TIMEOUT_SECONDS)
    except requests.exceptions.ConnectionError:
        raise SystemExit(
            "No se pudo conectar a Kong en http://localhost:8000.\n"
            "Asegurate de haber arrancado Kong con:  ./start-kong.sh"
        )

    if resp.status_code != 200:
        raise SystemExit(
            f"Kong respondio con error {resp.status_code}:\n{resp.text}"
        )

    data = resp.json()
    # Kong devuelve formato compatible con OpenAI.
    return data["choices"][0]["message"]["content"]


def modo_interactivo():
    """Chat por terminal con memoria de la conversacion."""
    print("Chat con Claude via Kong. Escribe 'salir' para terminar.\n")
    historial = []
    while True:
        try:
            pregunta = input("Tu: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nHasta luego.")
            break

        if pregunta.lower() in ("salir", "exit", "quit"):
            print("Hasta luego.")
            break
        if not pregunta:
            continue

        respuesta = preguntar(pregunta, historial)
        print(f"\nClaude: {respuesta}\n")

        # Guardar el turno en el historial para mantener contexto.
        historial.append({"role": "user", "content": pregunta})
        historial.append({"role": "assistant", "content": respuesta})


if __name__ == "__main__":
    # Si pasan un argumento, lo tratamos como pregunta unica.
    # Si no, entramos en modo interactivo.
    if len(sys.argv) > 1:
        pregunta = " ".join(sys.argv[1:])
        print(preguntar(pregunta))
    else:
        modo_interactivo()
